// 1.1

// let counter = 0;
// counter++;

// alert(counter)

// 1.2

// let num = 5;
// alert (num);

// num = 10;
// alert(num);

// 1.3

// let b = 10 + 20 + 30;
// alert(b);

// 1.4

// let a=100;
// let b=40;
// let c=a-b;

// let d=20;
// let result= c+d;

// alert(result)

// 1.5

// 13

// 1.6

// let a = 13;
// let b = 5;
// let c = a % b;
// alert (c);

// 1.7 - 72

// 1.8

// const birthDate = "07/30/1999";
// console.log(birthDate);